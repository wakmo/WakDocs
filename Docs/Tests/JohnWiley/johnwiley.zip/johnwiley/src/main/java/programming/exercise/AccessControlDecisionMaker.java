package programming.exercise;

public interface AccessControlDecisionMaker
{
    public boolean performAccessCheck(String book);
}
