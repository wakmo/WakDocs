Name : Wakkir Muzammil
Date : 2014-07-15
Email : wakkir@yahoo.com


Run following command to execute the program with the test report

>mvn clean install site

Please open the following URL on your browser to see the test result and coverage

>johnwiley\target\site\index.html
>johnwiley/target/site/surefire-report.html
>johnwiley/target/site/cobertura/index.html